from django.apps import AppConfig


class DecesareeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DeCesaree'
